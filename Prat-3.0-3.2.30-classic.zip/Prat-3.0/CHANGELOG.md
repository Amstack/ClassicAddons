# Prat 3.0

## [3.2.30](https://github.com/sylvanaar/prat-3-0/tree/3.2.30) (2019-08-28)
[Full Changelog](https://github.com/sylvanaar/prat-3-0/compare/3.2.29...3.2.30)

- Move around fills  
- Fix sendwho, getnumfriends and getfriendinfo  
- Update README.md  