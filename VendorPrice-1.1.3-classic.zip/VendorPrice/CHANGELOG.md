# Vendor Price

## [1.1.3](https://github.com/ketho-wow/VendorPrice/tree/1.1.3) (2019-08-28)
[Full Changelog](https://github.com/ketho-wow/VendorPrice/compare/1.1.2...1.1.3)

- Fixed error when using Auctionator  
    Fixed prices not being shown for the tradeskill window while at the vendor  
