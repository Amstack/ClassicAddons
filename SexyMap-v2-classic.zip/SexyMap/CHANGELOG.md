# SexyMap

## [v2-classic](https://github.com/funkydude/SexyMap/tree/v2-classic) (2019-08-12)
[Full Changelog](https://github.com/funkydude/SexyMap/compare/v1-classic...v2-classic)

- Revert accidental locale removals  
- Buttons: Rename "Calendar" to "Day/Night Indicator" and set the default to always hide.  
- Hide the "X" button that collapses the minimap.  
- correct toc version  
