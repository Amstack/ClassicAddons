local L = LibStub("AceLocale-3.0"):NewLocale("InFlight", "deDE")
if not L then return end

L["Nighthaven"] = "Nachthafen"
L["NighthavenGossipA"] = "Ich würde gerne nach Rut'theran fliegen"
L["NighthavenGossipH"] = "Ich würde gerne nach Donnerfels fliegen"
L["Return"] = "Zurück zum Startpunkt"
L["Rut'theran Village"] = "Rut'theran"
L["Stormwind City"] = "Sturmwind"
L["StormwindCityGossip"] = "Ich möchte durch den Hafen von Sturmwind fliegen"
L["Thunder Bluff"] = "Donnerfels"
