local L = LibStub("AceLocale-3.0"):NewLocale("InFlight", "koKR")
if not L then return end

L["Nighthaven"] = "밤의 안식처"
L["NighthavenGossipA"] = "루테란 마을로 날아가고 싶습니다"
L["NighthavenGossipH"] = "썬더 블러프로 날아가고 싶어요"
L["Return"] = "돌아오다"
L["Rut'theran Village"] = "루테란 마을"
L["Stormwind City"] = "스톰윈드"
L["StormwindCityGossip"] = "스톰윈드 항구 주변을 한 바퀴 돌면서 구경했으면 좋겠습니다"
L["Thunder Bluff"] = "썬더 블러프"
