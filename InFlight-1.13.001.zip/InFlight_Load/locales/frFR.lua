local L = LibStub("AceLocale-3.0"):NewLocale("InFlight", "frFR")
if not L then return end

L["Nighthaven"] = "Havrenuit"
L["NighthavenGossipA"] = "J’aimerais voler jusqu’au village de Rut’theran"
L["NighthavenGossipH"] = "J’aimerais voler jusqu’aux Pitons-du-Tonnerre"
L["Return"] = "Revenir"
L["Rut'theran Village"] = "Rut’theran"
L["Stormwind City"] = "Hurlevent"
L["StormwindCityGossip"] = "J’aimerais survoler le port de Hurlevent"
L["Thunder Bluff"] = "Les Pitons-du-Tonnerre"
