local L = LibStub("AceLocale-3.0"):NewLocale("InFlight", "itIT")
if not L then return end

L["Nighthaven"] = "Nottequieta"
L["NighthavenGossipA"] = "Vorrei andare a Rut'theran"
L["NighthavenGossipH"] = "Vorrei andare a Picco del Tuono"
L["Return"] = "Tornare"
L["Rut'theran Village"] = "Rut'theran"
L["Stormwind City"] = "Roccavento"
L["StormwindCityGossip"] = "Vorrei fare un volo sopra il Porto di Roccavento"
L["Thunder Bluff"] = "Picco del Tuono"
