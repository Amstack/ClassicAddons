local L = LibStub("AceLocale-3.0"):NewLocale("InFlight", "ptBR")
if not L then return end

L["Nighthaven"] = "Refúgio Noturno"
L["NighthavenGossipA"] = "Eu quero voar até a Vila de Rut'theran"
L["NighthavenGossipH"] = "Eu gostaria de voar para o Penhasco do Trovão"
L["Return"] = "Volta"
L["Rut'theran Village"] = "Vila de Rut'theran"
L["Stormwind City"] = "Ventobravo"
L["StormwindCityGossip"] = "Eu quero sobrevoar o Porto de Ventobravo"
L["Thunder Bluff"] = "Penhasco do Trovão"
