## v4.8.2 Changes

* Fixed bug with account syncing not connecting in some situations.
* Adjusted default Auctioning operation prices to be invalid if there's no AuctionDB data.
* Fixed various errors from cancel scans and generally sped up Auctioning scan processing.
* Fixed bug with positioning of merchant frame when using other addons.

[Known Issues](http://support.tradeskillmaster.com/display/KB/TSM4+Currently+Known+Issues)
