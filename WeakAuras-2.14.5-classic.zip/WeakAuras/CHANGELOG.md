# [2.14.5](https://github.com/WeakAuras/WeakAuras2/tree/2.14.5) (2019-08-27)

[Full Changelog](https://github.com/WeakAuras/WeakAuras2/compare/2.14.4...2.14.5)

## Highlights

 - Let's call this the Reloe and Causese release
- Bulk editing very large groups is now way faster
- Your usual round of bug fixes 

## Commits

InfusOnWoW (3):

- Pause dynamic groups in setAll
- Text: Run custom text function in Update
- Fix sorting of DynamicGroups

Stanzilla (2):

- update opdeps for LibClassicCasterino
- don't watch rune cooldowns on classic

mrbuds (4):

- fix options for unsuported regions
- fix import of unsupported region
- add region.Update for "fallback" regionType
- bossmod triggers: fix arithmetic error if state.extend is nil fix #1625

